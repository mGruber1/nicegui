import Styles from './Content.module.scss'

const Content = () => {
    return (
        <></>
    )
}

export default Content